export const GET_DATA = "GET_DATA";
export const CLICK_CITY = "CLICK_CITY";
export const GET_FILTER = "GET_FILTER";
export const MAP_COUNTY = "MAP_COUNTY";