import React from "react";
import {Col} from "antd";


import Filter from "./Filter";
import FirstThreeCounty from "./FirstThreeCounty";

class FilterContain extends React.Component {
  
    
      




      


  render() {
  
    return (
       <div>
           <Col>
           <Filter/>
           <FirstThreeCounty/>
           </Col>
        </div>
    );

    
    

  }
}




export default FilterContain;
